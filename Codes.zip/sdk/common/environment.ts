export const environment = {
  log:{url: 'http://localhost:3000'},
//  log:{url: process.env.LOGGER_URL || 'http://localhost:3000'},
//  db:{url:process.env.DB_URL||'mongodb://localhost/logs-universe'},
//  security:{saltRounds:10}
}
