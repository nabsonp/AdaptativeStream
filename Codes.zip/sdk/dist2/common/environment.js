"use strict";
exports.__esModule = true;
exports.environment = {
    log: { url: 'http://localhost:3000' }
};
